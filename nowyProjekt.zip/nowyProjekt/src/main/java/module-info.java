module com.example.nowyprojekt {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.nowyprojekt to javafx.fxml;
    exports com.example.nowyprojekt;
}