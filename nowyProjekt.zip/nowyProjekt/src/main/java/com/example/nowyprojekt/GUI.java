package com.example.nowyprojekt;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class GUI extends Application {
    private Plan plan;

    public GUI(Plan plan) {
        this.plan = plan;
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("System Rezerwacji Sal / Podział Godzin");

        BorderPane layout = new BorderPane();

        // Menu górne
        MenuBar menuBar = new MenuBar();
        Menu menuPlik = new Menu("Plik");
        MenuItem zapisz = new MenuItem("Zapisz");
        MenuItem wczytaj = new MenuItem("Wczytaj");
        menuPlik.getItems().addAll(zapisz, wczytaj);
        menuBar.getMenus().add(menuPlik);

        zapisz.setOnAction(e -> plan.zapiszDoPliku("plan.txt"));
        wczytaj.setOnAction(e -> plan.wczytajZPliku("plan.txt"));

        layout.setTop(menuBar);

        // Środkowy panel do wyświetlania podziałów
        TextArea outputArea = new TextArea();
        layout.setCenter(outputArea);

        // Dolny panel do dodawania zajęć
        VBox addPanel = new VBox();
        addPanel.setSpacing(10);

        // Przykładowe elementy do dodawania zajęć
        TextField kierunekField = new TextField();
        kierunekField.setPromptText("Kierunek");

        TextField nazwaPrzedmiotuField = new TextField();
        nazwaPrzedmiotuField.setPromptText("Nazwa przedmiotu");

        TextField prowadzacyField = new TextField();
        prowadzacyField.setPromptText("Prowadzący");

        TextField nrSaliField = new TextField();
        nrSaliField.setPromptText("Numer sali");

        TextField dzienField = new TextField();
        dzienField.setPromptText("Dzień tygodnia");

        TextField godzinaField = new TextField();
        godzinaField.setPromptText("Godzina");

        TextField nrGrupyField = new TextField();
        nrGrupyField.setPromptText("Numer grupy");

        Button dodajLaboratorium = new Button("Dodaj Laboratorium");
        dodajLaboratorium.setOnAction(e -> {
            Laboratorium lab = new Laboratorium(
                    kierunekField.getText(),
                    nazwaPrzedmiotuField.getText(),
                    prowadzacyField.getText(),
                    Integer.parseInt(nrSaliField.getText()),
                    dzienField.getText(),
                    Integer.parseInt(godzinaField.getText()),
                    Integer.parseInt(nrGrupyField.getText())
            );
            plan.dodajZajecia(lab);
            outputArea.appendText("Dodano laboratorium: " + lab.getNazwaPrzedmiotu() + "\n");
        });

        Button dodajWykład = new Button("Dodaj Wykład");
        dodajWykład.setOnAction(e -> {
            Wykład wyklad = new Wykład(
                    kierunekField.getText(),
                    nazwaPrzedmiotuField.getText(),
                    prowadzacyField.getText(),
                    Integer.parseInt(nrSaliField.getText()),
                    dzienField.getText(),
                    Integer.parseInt(godzinaField.getText())
            );
            plan.dodajZajecia(wyklad);
            outputArea.appendText("Dodano wykład: " + wyklad.getNazwaPrzedmiotu() + "\n");
        });

        Button dodajProjekt = new Button("Dodaj Projekt");
        dodajProjekt.setOnAction(e -> {
            Projekt projekt = new Projekt(
                    kierunekField.getText(),
                    nazwaPrzedmiotuField.getText(),
                    prowadzacyField.getText(),
                    Integer.parseInt(nrSaliField.getText()),
                    dzienField.getText(),
                    Integer.parseInt(godzinaField.getText()),
                    Integer.parseInt(nrGrupyField.getText()),
                    Integer.parseInt(nrGrupyField.getText()) // Zakładamy, że numer grupy1 i grupy2 są takie same dla uproszczenia
            );
            plan.dodajZajecia(projekt);
            outputArea.appendText("Dodano projekt: " + projekt.getNazwaPrzedmiotu() + "\n");
        });

        addPanel.getChildren().addAll(kierunekField, nazwaPrzedmiotuField, prowadzacyField, nrSaliField, dzienField, godzinaField, nrGrupyField, dodajLaboratorium, dodajWykład, dodajProjekt);
        layout.setBottom(addPanel);

        Scene scene = new Scene(layout, 800, 600);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
