package com.example.nowyprojekt;

public class Laboratorium extends Zajecia {
    private int nrGrupy;

    public Laboratorium(String kierunek, String nazwaPrzedmiotu, String prowadzacy, int nrSali, String dzien, int godzina, int nrGrupy) {
        super(kierunek, nazwaPrzedmiotu, prowadzacy, nrSali, dzien, godzina);
        this.nrGrupy = nrGrupy;
    }

    @Override
    public boolean czyJestDlaGrupy(int nrGrupy) {
        return this.nrGrupy == nrGrupy;
    }
}
