package com.example.nowyprojekt;

public class Wykład extends Zajecia {

    public Wykład(String kierunek, String nazwaPrzedmiotu, String prowadzacy, int nrSali, String dzien, int godzina) {
        super(kierunek, nazwaPrzedmiotu, prowadzacy, nrSali, dzien, godzina);
    }

    @Override
    public boolean czyJestDlaGrupy(int nrGrupy) {
        return true;
    }
}
