package com.example.nowyprojekt;

import java.util.ArrayList;
import java.util.List;

public class Plan {
    private List<Zajecia> zajeciaList;

    public Plan() {
        this.zajeciaList = new ArrayList<>();
    }

    public void dodajZajecia(Zajecia zajecia) {
        if (!czyJestKolizja(zajecia)) {
            zajeciaList.add(zajecia);
        } else {
            System.out.println("Kolizja zajęć!");
        }
    }

    public void usunZajecia(Zajecia zajecia) {
        zajeciaList.remove(zajecia);
    }

    public List<Zajecia> wypiszPodzialDlaDnia(String dzien) {
        List<Zajecia> wynik = new ArrayList<>();
        for (Zajecia z : zajeciaList) {
            if (z.getDzien().equals(dzien)) {
                wynik.add(z);
            }
        }
        return wynik;
    }

    public List<Zajecia> wypiszPodzialDlaGrupy(int nrGrupy) {
        List<Zajecia> wynik = new ArrayList<>();
        for (Zajecia z : zajeciaList) {
            if (z.czyJestDlaGrupy(nrGrupy)) {
                wynik.add(z);
            }
        }
        return wynik;
    }

    public List<Zajecia> wypiszPodzialDlaSali(int nrSali) {
        List<Zajecia> wynik = new ArrayList<>();
        for (Zajecia z : zajeciaList) {
            if (z.getNrSali() == nrSali) {
                wynik.add(z);
            }
        }
        return wynik;
    }

    private boolean czyJestKolizja(Zajecia noweZajecia) {
        for (Zajecia z : zajeciaList) {
            if (z.kolizja(noweZajecia)) {
                return true;
            }
        }
        return false;
    }

    public void zapiszDoPliku(String nazwaPliku) {
        // Implementacja zapisu do pliku
    }

    public void wczytajZPliku(String nazwaPliku) {
        // Implementacja wczytywania z pliku
    }
}
