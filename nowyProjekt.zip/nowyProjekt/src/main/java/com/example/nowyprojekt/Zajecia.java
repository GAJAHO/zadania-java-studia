package com.example.nowyprojekt;

public abstract class Zajecia {
    private String kierunek;
    private String nazwaPrzedmiotu;
    private String prowadzacy;
    private int nrSali;
    private String dzien;
    private int godzina;

    public Zajecia(String kierunek, String nazwaPrzedmiotu, String prowadzacy, int nrSali, String dzien, int godzina) {
        this.kierunek = kierunek;
        this.nazwaPrzedmiotu = nazwaPrzedmiotu;
        this.prowadzacy = prowadzacy;
        this.nrSali = nrSali;
        this.dzien = dzien;
        this.godzina = godzina;
    }

    public abstract boolean czyJestDlaGrupy(int nrGrupy);

    public boolean kolizja(Zajecia inneZajecia) {
        return this.nrSali == inneZajecia.nrSali && this.dzien.equals(inneZajecia.dzien) && this.godzina == inneZajecia.godzina;
    }

    // Gettery i settery

    public String getKierunek() {
        return kierunek;
    }

    public String getNazwaPrzedmiotu() {
        return nazwaPrzedmiotu;
    }

    public String getProwadzacy() {
        return prowadzacy;
    }

    public int getNrSali() {
        return nrSali;
    }

    public String getDzien() {
        return dzien;
    }

    public int getGodzina() {
        return godzina;
    }
}
