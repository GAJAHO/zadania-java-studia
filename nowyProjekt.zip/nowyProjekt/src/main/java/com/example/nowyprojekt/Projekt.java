package com.example.nowyprojekt;

public class Projekt extends Zajecia {
    private int nrGrupy1;
    private int nrGrupy2;

    public Projekt(String kierunek, String nazwaPrzedmiotu, String prowadzacy, int nrSali, String dzien, int godzina, int nrGrupy1, int nrGrupy2) {
        super(kierunek, nazwaPrzedmiotu, prowadzacy, nrSali, dzien, godzina);
        this.nrGrupy1 = nrGrupy1;
        this.nrGrupy2 = nrGrupy2;
    }

    @Override
    public boolean czyJestDlaGrupy(int nrGrupy) {
        return this.nrGrupy1 == nrGrupy || this.nrGrupy2 == nrGrupy;
    }
}
